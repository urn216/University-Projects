package code.shapes;

import code.Polygon;

public interface Shape {
  public static Polygon generate() {return null;}
}
