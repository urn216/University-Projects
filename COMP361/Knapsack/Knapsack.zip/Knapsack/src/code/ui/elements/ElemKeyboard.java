package code.ui.elements;

import code.ui.UIElement;

public class ElemKeyboard extends UIElement {

}
