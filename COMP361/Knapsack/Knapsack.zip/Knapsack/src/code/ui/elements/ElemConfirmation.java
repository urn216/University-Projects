package code.ui.elements;

import code.ui.UIElement;

public class ElemConfirmation extends UIElement {

}
