package code.ui;

/**
* Defines different ui states
*/
public enum UIState {
  //general
  DEFAULT,
  O_1,
  O_N,
  GEN_PROB,
  DISPLAY
}
