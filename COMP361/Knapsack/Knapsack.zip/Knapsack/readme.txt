the .jar file should be runnable.

using the mouse, you can click on the buttons on screen to select which method of knapsack you would like to use.

ESC   returns to the previous menu.
ENTER clicks on whatever button you have highlighted. (Same as left-clicking with your mouse)

When you have managed to run an algorithm, a file should be created in the same directory as the .jar file called output.txt

This output file should display a copy of whatever was printed to your screen when you ran the algorithm. 
This is useful if you wish to process the output or if the output was too long to fit entirely on the screen.

If you cannot get the program to run for whatever reason there are sample screenshots supplied to show what it should look like.
You are also welcome to copy the contents of 'run.bat' into a terminal to recompile. 
.bat files don't work on linux computers, so you'll have to copy to a terminal

William Kilty
300473541