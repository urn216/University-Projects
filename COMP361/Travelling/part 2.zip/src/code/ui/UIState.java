package code.ui;

/**
* Defines different ui states
*/
public enum UIState {
  //general
  DEFAULT,
  DATASET,
  DISPLAY
}
