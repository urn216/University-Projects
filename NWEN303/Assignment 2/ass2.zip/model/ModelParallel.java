package model;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class ModelParallel extends Model {

	@Override
	public void step() {
		this.p.parallelStream().forEach(p -> p.interact(this));
		this.p.parallelStream().forEach(p -> p.move());
		mergeParticles();
		updateGraphicalRepresentation();
	}

	@Override
	public void mergeParticles(){
		List<Particle> deadPs = this.p.parallelStream().filter(p -> !p.impacting.isEmpty()).collect(Collectors.toList());
		this.p.removeAll(deadPs);
		while(!deadPs.isEmpty()){
			Particle current=deadPs.remove(deadPs.size()-1);
			Set<Particle> ps=getSingleChunck(current);
			deadPs.removeAll(ps);
			this.p.add(mergeParticles(ps));
		}
	}
}