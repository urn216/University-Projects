package Tests;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import datasets.DataSetLoader;
import datasets.DataSetLoaderParallel;
import gui.Gui;
import model.Model;
import model.ModelParallel;
import model.Particle;

public class TestCorrectness {
	
	private boolean sameList(List<Particle> one, List<Particle> two) {
		if (one.size() != two.size()) return false;
		for (int i = 0; i < one.size(); i++) {
			if (!one.get(i).equals(two.get(i))) return false;
		}
		return true;
	}
	
	
	@Test
	public void testSetUp() {
	    Model ms=DataSetLoader.getElaborate(20, 70, 2,0.99);
	    ModelParallel mp=DataSetLoaderParallel.getElaborate(20, 70, 2,0.99);
	    
	    assertTrue(sameList(ms.p, mp.p));
	}
	
	@Test
	public void testDiffStep() {
	    Model ms=DataSetLoader.getElaborate(20, 70, 2,0.99);
	    ModelParallel mp=DataSetLoaderParallel.getElaborate(20, 70, 2,0.99);
	    
	    ms.step();
	    
	    assertFalse(sameList(ms.p, mp.p));
	}
	
	@Test
	public void testSameStep() {
	    Model ms=DataSetLoader.getElaborate(20, 70, 2,0.99);
	    ModelParallel mp=DataSetLoaderParallel.getElaborate(20, 70, 2,0.99);
	    
	    ms.step();
	    mp.step();
	    
	    assertTrue(sameList(ms.p, mp.p));
	}
	
	@Test
	public void testManySteps() {
	    Model ms=DataSetLoader.getElaborate(20, 70, 2,0.99);
	    ModelParallel mp=DataSetLoaderParallel.getElaborate(20, 70, 2,0.99);
	    
	    for (int i = 0; i < 100; i++) {
	    	ms.step();
	    }
	    for (int i = 0; i < 100; i++) {
	    	mp.step();
	    }
	    
	    assertTrue(sameList(ms.p, mp.p));
	}
	
	@Test
	public void testManyRegular() {
	    Model ms=DataSetLoader.getRegularGrid(20, 70, 2);
	    ModelParallel mp=DataSetLoaderParallel.getRegularGrid(20, 70, 2);
	    
	    for (int i = 0; i < 100; i++) {
	    	ms.step();
	    }
	    for (int i = 0; i < 100; i++) {
	    	mp.step();
	    }
	    
	    assertFalse(sameList(ms.p, mp.p));//assertfalse because without fixing the bug discussed in my report, this will never work. With the bug fixed this should asserttrue every time
	}
	
	@Test
	public void testGUI() {
	    Model ms=DataSetLoader.getElaborate(200, 700, 2, 0.5);
	    ModelParallel mp=DataSetLoaderParallel.getElaborate(200, 700, 2, 0.5);

	    assertTrue(sameList(ms.p, mp.p));
	    
	    Gui.invoke(ms);
	    Gui.invoke(mp);

	    assertTrue(sameList(ms.p, mp.p));
	}
}
