package Tests;
import java.util.List;
import java.util.stream.Collectors;

import org.junit.jupiter.api.Test;

import datasets.DataSetLoader;
import datasets.DataSetLoaderParallel;
import model.Model;
import model.ModelParallel;
import model.Particle;
/**
 * This test suite provides a look into the performance of different particle simulator models with different types of data.<p>
 * 
 * This is a modified test suite from Assignment 1. The pros and cons of this method are discussed in depth in that assignment
 */
public class TestPerformance {
	/**
	 * Gets the time in milliseconds it takes to run a runnable object a number of times.<p>
	 * 
	 * It does this by first garbage collecting - to make sure as much processing power as possible is able to be used here.<p>
	 * 
	 * It then runs through 'r' 'warmUp' times in order to force Java to prioritize this thread and settle into a consistent running time, 
	 * hopefully representative of how fast the algorithm runs in ideal circumstances.<p>
	 * 
	 * We then take the time at this moment, run through 'r' 'runs' times, and take the time afterwards.<p>
	 * 
	 * We subtract the second timing from the first, giving the number of milliseconds required to run 'r' 'runs' times in hopefully ideal circumstances.<p>
	 * 
	 * @param r the runnable object holding our forEach loop, running through each list in the dataset and sorting via the given implementation upon calling r.run()
	 * @param warmUp the number of times to run 'r' before timing our results
	 * @param runs the number of times to run 'r' to get a timing
	 * @return the milliseconds taken to run 'r' 'runs' times
	 */
	long timeOf(Runnable r,int warmUp,int runs) {
		System.gc();
		for(int i=0;i<warmUp;i++) {r.run();}
		long time0=System.currentTimeMillis();
		for(int i=0;i<runs;i++) {r.run();}
		long time1=System.currentTimeMillis();
		return time1-time0;
	}
	/**
	 * Gets the time in milliseconds to run a given particle simulator on a given dataset 200 times - after a warmup of 20,000 cycles - and then prints out
	 * that time in seconds.
	 * 
	 * @param m the model implementation to use
	 * @param name the name of the implementation. Just used for printing out the results
	 */
	void msg(Model m, String name) {
		List<Particle> ps = List.copyOf(m.p);
		long time=timeOf(()->{
			m.p = ps.parallelStream().map(p -> p.clone()).collect(Collectors.toList());
			for(int i = 0; i < 100; i++){m.step();}
		},1000,200);//realistically 20,000 to make the JIT do his job..
		System.out.println(name+" takes "+time/1000d+" seconds");
	}
	/**
	 * Takes in models made from a dataset of any given type, and passes them off to be tested. A very straightforward method.
	 * 
	 * @param ms The sequential model to test
	 * @param mp the parallel model to test
	 */
	void msgAll(Model ms, ModelParallel mp) {
		msg(ms,"Sequential Model");
		msg(mp,"  Parallel Model");
	}
	/**
	 * Tests the performance of each model implementation through the Elaborate dataset
	 */
	@Test
	void testElaborate() {
		System.out.println("On the data type Elaborate");
		msgAll(DataSetLoader.getElaborate(200, 700, 2, 0.99), DataSetLoaderParallel.getElaborate(200, 700, 2, 0.99));
	}
	/**
	 * Tests the performance of each model implementation through the RegularGrid dataset
	 */
	@Test
	void testRegular() {
		System.out.println("On the data type RegularGrid");
		msgAll(DataSetLoader.getRegularGrid(100, 800, 40), DataSetLoaderParallel.getRegularGrid(100, 800, 40));
	}
}