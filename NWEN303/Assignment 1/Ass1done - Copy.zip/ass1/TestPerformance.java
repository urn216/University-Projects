package ass1;

import java.util.Arrays;
import org.junit.jupiter.api.Test;

/**
 * This test suite provides a look into the performance of different sorting algorithms with different types of data.<p>
 * 
 * The pros of this testing method:<pre>
 * -  It looks to show the performance of algorithms in 'ideal circumstances' without interference from other systems.
 * -  It gives an aggregate result of a number of runs through, giving an 'average' speed, allowing for better comparisons.
 * -  It allows time for the thread to 'warm up' giving it the best chance possible to return accurate results.
 * -  It looks at different types of data, to see how algorithms handle various comparable implementations.
 * </pre>
 * The cons of this testing method:<pre>
 * -  It is not clear that the time returned at the end is an aggregation of 200 tests rather than just one test or an average
 * -  Though garbage collection attempts to eliminate wasted resources, there is no guarantee that the computer is not doing something else in the background
 * -  The warm-up time is a massive time investment. Running a test takes roughly 5 minutes for each data type
 * -  Only looks at time as a measure of performance. The resources required is just as valuable a measure, and this doesn't care about it.
 *    As a result of this, different machines will show wildly different performances, as well as background tasks affecting results.
 * </pre>
 * An alternative to this method would include resources in the measurements. ie, if one method requires a GB of RAM more than another, or whether the threads 
 * are being allocated 100% of the CPU every time.<p>
 * I'd also just show an average time rather than an aggregate, but that's mostly just preference.
 */
public class TestPerformance {
	/**
	 * Gets the time in milliseconds it takes to run a runnable object a number of times.<p>
	 * 
	 * It does this by first garbage collecting - to make sure as much processing power as possible is able to be used here.<p>
	 * 
	 * It then runs through 'r' 'warmUp' times in order to force Java to prioritize this thread and settle into a consistent running time, 
	 * hopefully representative of how fast the algorithm runs in ideal circumstances.<p>
	 * 
	 * We then take the time at this moment, run through 'r' 'runs' times, and take the time afterwards.<p>
	 * 
	 * We subtract the second timing from the first, giving the number of milliseconds required to run 'r' 'runs' times in hopefully ideal circumstances.<p>
	 * 
	 * @param r the runnable object holding our forEach loop, running through each list in the dataset and sorting via the given implementation upon calling r.run()
	 * @param warmUp the number of times to run 'r' before timing our results
	 * @param runs the number of times to run 'r' to get a timing
	 * @return the milliseconds taken to run 'r' 'runs' times
	 */
	long timeOf(Runnable r,int warmUp,int runs) {
		System.gc();
		for(int i=0;i<warmUp;i++) {r.run();}
		long time0=System.currentTimeMillis();
		for(int i=0;i<runs;i++) {r.run();}
		long time1=System.currentTimeMillis();
		return time1-time0;
	}
	/**
	 * Gets the time in milliseconds to run a given sorting algorithm on a given dataset 200 times - after a warmup of 20,000 cycles - and then prints out
	 * that time in seconds.
	 * 
	 * @param <T> The type of data within the dataset
	 * @param s the mergeSort implementation to use
	 * @param name the name of the implementation. Just used for printing out the results
	 * @param dataset the collection of data to sort via this sort implementation
	 */
	<T extends Comparable<? super T>>void msg(Sorter s,String name,T[][] dataset) {
		long time=timeOf(()->{
			for(T[]l:dataset){s.sort(Arrays.asList(l));}
		},20000,200);//realistically 20,000 to make the JIT do his job..
		System.out.println(name+" sort takes "+time/1000d+" seconds");
	}
	/**
	 * Takes in a dataset of any given type, and passes it off to each of the mergeSort implementations. A very straightforward method.
	 * 
	 * @param <T> The type of data within the dataset
	 * @param dataset the collection of data to sort via each implementation
	 */
	<T extends Comparable<? super T>>void msgAll(T[][] dataset) {
		//msg(new ISequentialSorter(),"Sequential insertion",TestBigInteger.dataset);//so slow
		//uncomment the former line to include performance of ISequentialSorter
		msg(new MSequentialSorter(),"Sequential merge sort",dataset);
		msg(new MParallelSorter1(),"Parallel merge sort (futures)",dataset);
		msg(new MParallelSorter2(),"Parallel merge sort (completablefutures)",dataset);
		msg(new MParallelSorter3(),"Parallel merge sort (forkJoin)",dataset);
	}
	/**
	 * Tests the performance of each mergeSort implementation through the BigInteger dataset
	 */
	@Test
	void testBigInteger() {
		System.out.println("On the data type BigInteger");
		msgAll(TestBigInteger.dataset);
	}
	/**
	 * Tests the performance of each mergeSort implementation through the Float dataset
	 */
	@Test
	void testFloat() {
		System.out.println("On the data type Float");
		msgAll(TestFloat.dataset);
	}
	/**
	 * Tests the performance of each mergeSort implementation through the Point dataset
	 */
	@Test
	void testPoint() {
		System.out.println("On the data type Point");
		msgAll(TestPoint.dataset);
	}
	/**
	 * Tests the performance of each mergeSort implementation through the String dataset
	 */
	@Test
	void testString() {
		System.out.println("On the data type String");
		msgAll(TestString.dataset);
	}
}
/*
With the model solutions, on a lab machine (2019) we may get those results:
On the data type Float
Sequential merge sort sort takes 1.178 seconds
Parallel merge sort (futures) sort takes 0.609 seconds
Parallel merge sort (completablefutures) sort takes 0.403 seconds
Parallel merge sort (forkJoin) sort takes 0.363 seconds
On the data type Point
Sequential merge sort sort takes 1.373 seconds
Parallel merge sort (futures) sort takes 0.754 seconds
Parallel merge sort (completablefutures) sort takes 0.541 seconds
Parallel merge sort (forkJoin) sort takes 0.48 seconds
On the data type BigInteger
Sequential merge sort sort takes 1.339 seconds
Parallel merge sort (futures) sort takes 0.702 seconds
Parallel merge sort (completablefutures) sort takes 0.452 seconds
Parallel merge sort (forkJoin) sort takes 0.492 seconds

On another lab machine in 2021 we get those results:
//they must have optimized sequential execution quite a bit!
On the data type Float
Sequential merge sort sort takes 0.635 seconds
Parallel merge sort (futures) sort takes 0.475 seconds //with a smart trick we may get 0.241 instead
Parallel merge sort (completablefutures) sort takes 0.25 seconds
Parallel merge sort (forkJoin) sort takes 0.253 seconds
On the data type Point
Sequential merge sort sort takes 0.76 seconds //with a smart trick we may get 0.296 instead
Parallel merge sort (futures) sort takes 0.505 seconds
Parallel merge sort (completablefutures) sort takes 0.279 seconds
Parallel merge sort (forkJoin) sort takes 0.296 seconds
On the data type BigInteger
Sequential merge sort sort takes 0.871 seconds
Parallel merge sort (futures) sort takes 0.574 seconds //with a smart trick we may get 0.372 instead
Parallel merge sort (completablefutures) sort takes 0.354 seconds
Parallel merge sort (forkJoin) sort takes 0.338 seconds

 */