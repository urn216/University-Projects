package ass1;

import java.util.List;
import java.util.concurrent.CompletableFuture;

/**
 * Merge Sort with CompletableFutures 
 * <pre>
 * Task 3: 
 * ~~~~~~~ 
 * 
 * This method has the advantage of requiring very few lines of code to make work.
 * CompletableFutures take care of a lot of the nitty-gritty work for you, making 
 * code very streamlined and easy to handle. Another advantage is the ability to 
 * reduce the amount of time spent waiting around for work to complete, with the 
 * help of 'thenCombine', allowing workers to manage thread work intelligently, 
 * only waiting for other threads when absolutely necessary. This technique is fast 
 * and easy to work with. I learned from this implementation how to manage non-locking 
 * code.
 * </pre>
 */
public class MParallelSorter2 implements Sorter {

	@Override
	public <T extends Comparable<? super T>> List<T> sort(List<T> list) {
		if (list == null || list.isEmpty()) return list;
		return mSort(list, 0, list.size()-1);
	}

	/**
	 * implements the merge-sort recursive algorithm. Now with CompletableFutures!
	 * 
	 * @param <T> The object contained within the list to sort
	 * @param list the unsorted list
	 * @param a the index to start sorting from
	 * @param c the final index to sort to
	 * @return a sorted list
	 */
	public static <T extends Comparable<? super T>> List<T> mSort(List<T> list, int a, int c) {
		//if there are less than 20 elements to sort, do the rest in sequence
		if (c-a < 20) return MSequentialSorter.mSort(list, a, c);

		//divide into two sublists, and sort them in parallel
		int b = (a+c)/2;
		CompletableFuture<List<T>> f1 = CompletableFuture.supplyAsync(()->mSort(list, a, b));
		CompletableFuture<List<T>> f2 = CompletableFuture.supplyAsync(()->mSort(list, b+1, c));

		//merge the now sorted sublists
		return f1.thenCombine(f2, (l1,l2)->(MSequentialSorter.merge(l1,l2))).join();
	}

}