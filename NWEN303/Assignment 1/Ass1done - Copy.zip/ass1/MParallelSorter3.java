package ass1;

import java.util.List;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.RecursiveTask;

/**
 * Merge Sort with ForkJoin
 * <pre>
 * Task 3: 
 * ~~~~~~~ 
 * 
 * This implementation has the advantage of resembling pure thread work, removing a lot
 * of the obfuscation in the other parallelization methods. Each new thread is a new object
 * which has its compute method called exactly once. This provides a better understanding of
 * how threading works under the hood. This method lends itself very well to recursive tasks
 * such as this one. It also has the advantage of being incredibly fast, often the fastest of
 * the four implementations. Through this implementation I learned why Futures and CompletableFutures
 * obfuscate so much of the setup. It's a lot quicker to use one of those libraries.
 * CompletableFutures is on the same level - performance wise - anyway.
 * </pre>
 */
public class MParallelSorter3 implements Sorter {

	/**
	 * the ForkJoinPool used by our ForkJoins
	 */
	private static final ForkJoinPool pool = new ForkJoinPool();

	@Override
	public <T extends Comparable<? super T>> List<T> sort(List<T> list) {
		if (list == null || list.isEmpty()) return list;
		return pool.invoke(new MergeSorter<T>(list, 0, list.size()-1));
	}

}

/**
 * class for merge-sort. To be used for ForkJoining
 *
 * @param <T> The object contained within the list to sort
 */
class MergeSorter<T extends Comparable<? super T>> extends RecursiveTask<List<T>> {

	/**the unsorted list to read*/
	private final List<T> list;
	/**lowest index*/
	private final int a;
	/**highest index*/
	private final int c;

	/**version number. Ignore*/
	private static final long serialVersionUID = 1L;

	/**
	 * implements the merge-sort recursive algorithm. Now with ForkJoin!
	 * 
	 * @param list the unsorted list
	 * @param a the index to start sorting from
	 * @param c the final index to sort to
	 */
	public MergeSorter(List<T> list, int a, int c) {
		this.list = list;
		this.a = a;
		this.c = c;
	}

	@Override
	protected List<T> compute() {
		//if there are less than 20 elements to sort, do the rest in sequence
		if (c-a < 20) return MSequentialSorter.mSort(list, a, c);

		//divide into two sublists, and sort them in parallel
		int b = (a+c)/2;
		MergeSorter<T> f1 = new MergeSorter<T>(list, a, b);
		MergeSorter<T> f2 = new MergeSorter<T>(list, b+1, c);
		invokeAll(f1, f2);

		//merge the now sorted sublists
		return MSequentialSorter.merge((List<T>) f1.join(), (List<T>) f2.join());
	}

}