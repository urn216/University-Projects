package ass1;

import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * Merge Sort with Futures
 * <pre>
 * Task 3: 
 * ~~~~~~~ 
 * 
 * This implementation utilizes futures, which have the benefit of closely resembling sequential code.
 * The implementation, therefore, is much easier than CompletableFutures and ForkJoin. The benefit of 
 * using this implementation over sequential code is the performance. With very little extra coding work,
 * you get an output on average about twice as fast. Another advantage over the others is it requires 
 * specificity in declaring the threadPool to use. This develops understanding of which threading methods
 * and which number of threads work best for your machine. It also helps build an understanding of exception 
 * handling around thread work.
 * </pre>
 */
public class MParallelSorter1 implements Sorter {

	/**
	 * the threadpool used by our futures
	 */
	private static final ExecutorService pool = Executors.newWorkStealingPool(10);

	/**
	 * Waits if necessary for the computation to complete, and then retrieves its result.
	 * 
	 * @param <E> The object type contained within the future
	 * @param f the future to retrieve from
	 * @return the result taken from the future
	 */
	public static <E> E get(Future<E> f) {
		try{ return f.get(); }
		catch(InterruptedException e) {
			Thread.currentThread().interrupt();
			throw new Error(e);
		}
		catch (ExecutionException e) {
			Throwable t=e.getCause();
			if(t instanceof RuntimeException rt){ throw rt; }
			if(t instanceof Error et){ throw et; }
			throw new Error("Unexpected Checked Exception",t);
		}
	}

	@Override
	public <T extends Comparable<? super T>> List<T> sort(List<T> list) {
		if (list == null || list.isEmpty()) return list;
		return mSort(list, 0, list.size()-1);
	}

	/**
	 * implements the merge-sort recursive algorithm. Now with Futures!
	 * 
	 * @param <T> The object contained within the list to sort
	 * @param list the unsorted list
	 * @param a the index to start sorting from
	 * @param c the final index to sort to
	 * @return a sorted list
	 */
	public static <T extends Comparable<? super T>> List<T> mSort(List<T> list, int a, int c) {
		//if there are less than 20 elements to sort, do the rest in sequence
		if (c-a < 20) return MSequentialSorter.mSort(list, a, c);

		//divide into two sublists, and sort them in parallel
		int b = (a+c)/2;
		Future<List<T>> f = pool.submit(()->mSort(list, b+1, c));
		List<T> l1 = mSort(list, a, b);
		List<T> l2 = get(f);

		//merge the now sorted sublists
		return MSequentialSorter.merge(l1, l2);
	}

}