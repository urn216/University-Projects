package ass1;

import java.util.Random;

import org.junit.jupiter.api.Test;

/**
 * A new test suite using Strings, our methods should put everything into alphabetical order
 */
public class TestString {

	/**
	 * creates a dataset to use in testing, consisting of lists of strings in various orders to test sorting
	 */
	static public String[][] dataset={
			{"aaa","abc","acc","add","aee","fff"},
			{"hello","world","test","me","please","thanks"},
			{"z","y","b","a"},
			{},
			manyOrdered(10000),
			manyReverse(10000),
			manyRandom(10000)
	};
	/**
	 * @param size the size of the array to create
	 * @return an array of random Strings
	 */
	static private String[] manyRandom(int size) {
		Random r=new Random(0);
		String[] result=new String[size];
		for(int i=0;i<size;i++){result[i]=""+(char)(r.nextInt(26)+65)+(char)(r.nextInt(26)+65)+(char)(r.nextInt(26)+65)+(char)(r.nextInt(26)+65)+(char)(r.nextInt(26)+65);}
		return result;
	}
	/**
	 * @param size the size of the array to create
	 * @return an array of Strings in reverse order
	 */
	static private String[] manyReverse(int size) {
		String[] result=new String[size];
		int chars = size/26+1;
		for(int i=0;i<size;i++){
			result[i]="";
			for (int c = 0; c < chars; c++) {result[i]+=(char)(90-((i+c)%26));}
		}
		return result;
	}
	/**
	 * @param size the size of the array to create
	 * @return an array of Strings in correct order
	 */
	static private String[] manyOrdered(int size) {
		String[] result=new String[size];
		int chars = size/26+1;
		for(int i=0;i<size;i++){
			result[i]="";
			for (int c = 0; c < chars; c++) {result[i]+=(char)(65+((i+c)%26));}
		}
		return result;
	}

	/**
	 * tests sequential insertion sorter on the dataset
	 */
	@Test
	public void testISequentialSorter() {
		Sorter s=new ISequentialSorter();
		for(String[]l:dataset){TestHelper.testData(l,s);}
	}
	/**
	 * tests sequential merge sorter on the dataset
	 */
	@Test
	public void testMSequentialSorter() {
		Sorter s=new MSequentialSorter();
		for(String[]l:dataset){TestHelper.testData(l,s);}
	}
	/**
	 * tests parallel Futures merge sorter on the dataset
	 */
	@Test
	public void testMParallelSorter1() {
		Sorter s=new MParallelSorter1();
		for(String[]l:dataset){TestHelper.testData(l,s);}
	}
	/**
	 * tests parallel CompletableFutures merge sorter on the dataset
	 */
	@Test
	public void testMParallelSorter2() {
		Sorter s=new MParallelSorter2();
		for(String[]l:dataset){TestHelper.testData(l,s);}
	}
	/**
	 * tests parallel ForkJoin merge sorter on the dataset
	 */
	@Test
	public void testMParallelSorter3() {
		Sorter s=new MParallelSorter3();
		for(String[]l:dataset){TestHelper.testData(l,s);}
	}
}
